/*
 * Reem, Hanady, Sara, Aisha
 * CPCS-324
 * Project Code
 * 4 June. 2023
 */
package GraphFramework;

import java.util.*;
import java.io.*;

public  class ShortestPathAlgorithm {
    
     Graph graph; 
   
}

